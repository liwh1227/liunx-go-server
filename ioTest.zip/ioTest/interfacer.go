package ioTest

type Server interface {
	StartServer() error
}
