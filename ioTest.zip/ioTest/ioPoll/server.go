package io_poll

/*
import (
	"fmt"
	//unix2 "github.com/MXi4oyu/golang.org/x/sys/unix"
	"golang.org/x/sys/unix"
	"ioTest"
)

type client struct {
	unix.PollFd
}
func startServer() error {
	//1.获取socketFd
	nSocketFd, err := ioTest.PreStartTcp()
	if err != nil {
		fmt.Println("Get socket error.", err)
		return err
	}

	pollFd := new([]*unix.PollFd,1024)
}
*/
